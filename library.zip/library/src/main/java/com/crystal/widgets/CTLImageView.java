package com.crystal.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Created by owais.ali on 9/7/2016.
 */
public class CTLImageView extends ImageView {

    public CTLImageView(Context context) {
        super(context);
    }

    public CTLImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CTLImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
